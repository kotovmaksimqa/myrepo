package lecture_11;

public class Parent {

    public static void doWmth() {
        System.out.println("Parent static method do Smth");
    }

    final static void doSmth() {
        System.out.println("");
    }

}
