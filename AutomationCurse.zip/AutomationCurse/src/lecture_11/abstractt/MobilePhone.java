package lecture_11.abstractt;

public class MobilePhone extends Phone{
    @Override
    public void call() {
        System.out.println("Mob phone call");
    }
}
