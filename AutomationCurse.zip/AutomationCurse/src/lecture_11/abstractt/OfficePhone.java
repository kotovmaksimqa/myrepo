package lecture_11.abstractt;

public class OfficePhone extends Phone {
    @Override
    public void call() {
        System.out.println("Wired Phone");
    }
}
