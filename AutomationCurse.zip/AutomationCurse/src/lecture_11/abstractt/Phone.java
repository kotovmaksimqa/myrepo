package lecture_11.abstractt;

public abstract class Phone {

    public void ring() {
        System.out.println("trtr");
    }

    public abstract void call();

}
