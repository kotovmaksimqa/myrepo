package Infrastructure.webdrivermanager;

import Infrastructure.config.ConfigurationManager;

public class WebDriverManager {

    public String create() {
        String browser = ConfigurationManager.getInstance().getTestBrowser();
        switch (browser) {
            case "chrome":
                return "Google Chrome";
            case "firefox":
                return "Mozilla Firefox";
            case "safari":
                return "Apple Safari";
            case "ie":
                return "MS Internet Explorer";
            default:
                return "Invalid";
        }
    }
    public void destroy(String browser) {}

}
