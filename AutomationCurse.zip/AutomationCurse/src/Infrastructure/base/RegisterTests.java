package Infrastructure.base;

public class RegisterTests extends AuthTestBase {

    @Override
    public void setUp() {
        super.setUp();

        logger.log("Click register button");
    }


}
