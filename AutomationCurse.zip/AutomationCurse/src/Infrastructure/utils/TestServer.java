package Infrastructure.utils;

import Infrastructure.config.ConfigurationManager;

public class TestServer {

    public String getTestServer() {
        String env = ConfigurationManager.getInstance().getTestEnv();
        switch (env) {
            case "local":
                return "http://localhost:63342";
            case "stage":
                return "http://stage-iavatar.jellyworkz.com";
            case "production":
                return "http://mysite.com";
            default:
                return "no one sites";
        }
    }
}
