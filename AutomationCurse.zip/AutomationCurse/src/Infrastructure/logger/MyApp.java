package Infrastructure.logger;

public class MyApp {
    public static void main(String[] args) {
    TestLogger logger = new StdTestLogger();
    logger.log("123");
    logger.log("123");
    logger.log("123");
    logger.log("123");

    logger = new FileTestLogger();
        logger.log("asdasd ");
        logger.log("asdasd ");
        logger.log("asdasd ");
        logger.log("asdasd ");

    }
}
