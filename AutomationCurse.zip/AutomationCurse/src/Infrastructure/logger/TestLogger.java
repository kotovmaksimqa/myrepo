package Infrastructure.logger;
public abstract class TestLogger {

    public abstract void log(String str);

}
