package inheritance;

import java.io.Reader;

public class Moderator extends Writer{
    public void postComment() {

        System.out.println("Post comment");

    }
}
