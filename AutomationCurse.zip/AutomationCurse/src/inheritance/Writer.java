package inheritance;

public class Writer extends Reader {
    public void writePost() {
        System.out.println("Write post articles");
    }
}
