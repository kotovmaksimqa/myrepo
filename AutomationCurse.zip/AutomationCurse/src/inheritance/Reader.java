package inheritance;

public class Reader {

    public void likeComment() {
        System.out.println("Like a comment");
    }
    public void postArticles() {

        System.out.println("Lala");

    }

}
