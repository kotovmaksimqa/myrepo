package inheritance;

public class MyApp {
    public static void main(String[] args) {
        Writer writer = new Writer();

        writer.writePost();


    }
}
