//package Lesson3;
//
//public class Lecture3 {
//    public static void main(String[] args) {
//
//        int condition = 5;
//        int result;
//
//
//
//
//        System.out.println("End of program");
//
//    }
//
//}
